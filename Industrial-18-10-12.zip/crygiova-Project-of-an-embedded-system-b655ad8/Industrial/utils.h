/*
 * utils.h
 *
 * Created: 27.09.2012 18:05:58
 *  Author: chrisgio
 */ 


#ifndef UTILS_H_
#define UTILS_H_

#include "globals.h"

void testLatch();
void SRAM_test(void);
void GAL_test(void* start, void* stop);
		
	




#endif /* UTILS_H_ */