/*
 * drvUART.c
 *
 * Created: 31.08.2012 14:22:26
 *  Author: jordifr
 */

#include "globals.h"


