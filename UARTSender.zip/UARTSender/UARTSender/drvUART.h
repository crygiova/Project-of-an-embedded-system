/*
 * drvUART.h
 *
 * Created: 31.08.2012 15:16:53
 *  Author: jordifr
 */ 


#ifndef DRVUART_H_
#define DRVUART_H_

void initUART(uint16_t ubrr);
uint8_t putC(uint8_t data);






#endif /* DRVUART_H_ */