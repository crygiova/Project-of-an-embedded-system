/*
 * globals.h
 *
 * Created: 31.08.2012 14:35:11
 *  Author: jordifr
 */ 


#ifndef GLOBALS_H_
#define GLOBALS_H_

#include <avr/io.h>

#define BAUD 9600
#define PRIVATE_UBRR F_CPU/16/BAUD-1



#endif /* GLOBALS_H_ */